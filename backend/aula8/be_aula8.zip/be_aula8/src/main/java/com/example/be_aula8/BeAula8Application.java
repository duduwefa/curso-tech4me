package com.example.be_aula8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeAula8Application {

	public static void main(String[] args) {
		SpringApplication.run(BeAula8Application.class, args);
	}

}
